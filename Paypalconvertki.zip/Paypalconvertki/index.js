
const express = require('express');
const path = require('path');
const nodemailer = require('nodemailer');
const axios = require('axios');
const app = express();
const PORT = 5000;

// Middleware
app.use(express.static('public'));
app.use(express.json());

// Email configuration
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

// WhatsApp notification function
async function sendWhatsAppNotification(message) {
  try {
    // Menggunakan WhatsApp Business API atau service seperti Twilio
    // Untuk demo, kita log ke console
    console.log('WhatsApp notification:', message);
    console.log('Sent to: +81 07091073142');
  } catch (error) {
    console.error('WhatsApp error:', error);
  }
}

// Email notification function
async function sendEmailNotification(orderDetails) {
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: process.env.ADMIN_EMAIL,
    subject: 'Pesanan Baru - Convert PayPal',
    html: `
      <h2>Pesanan Baru</h2>
      <p><strong>Jenis:</strong> ${orderDetails.type}</p>
      <p><strong>Nominal:</strong> ${orderDetails.amount}</p>
      <p><strong>Rate:</strong> ${orderDetails.rate}</p>
      <p><strong>Total:</strong> ${orderDetails.total}</p>
      <p><strong>Kontak Customer:</strong> ${orderDetails.contact}</p>
      <p><strong>Waktu:</strong> ${new Date().toLocaleString('id-ID')}</p>
    `
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log('Email notification sent');
  } catch (error) {
    console.error('Email error:', error);
  }
}

// Routes
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Order processing endpoint
app.post('/api/order', async (req, res) => {
  const { type, amount, contact } = req.body;
  
  // Calculate rates
  const buyRate = 15000 + 2000; // Rate beli (lebih mahal 2000)
  const sellRate = 15000 - 2000; // Rate jual (lebih murah 2000)
  
  const rate = type === 'buy' ? buyRate : sellRate;
  const total = amount * rate;
  
  const orderDetails = {
    type: type === 'buy' ? 'Beli Saldo PayPal' : 'Jual Saldo PayPal',
    amount: `$${amount}`,
    rate: `Rp ${rate.toLocaleString('id-ID')}`,
    total: `Rp ${total.toLocaleString('id-ID')}`,
    contact
  };
  
  // Send notifications
  await sendEmailNotification(orderDetails);
  await sendWhatsAppNotification(`Pesanan baru: ${orderDetails.type} - ${orderDetails.amount} - Total: ${orderDetails.total} - Kontak: ${contact}`);
  
  res.json({ success: true, orderDetails });
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running on http://0.0.0.0:${PORT}`);
});
