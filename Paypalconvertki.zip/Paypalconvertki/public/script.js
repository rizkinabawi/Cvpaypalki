
// Global variables
let currentModal = null;

// Modal functions
function openOrderModal(type) {
    const modal = document.getElementById('orderModal');
    const modalTitle = document.getElementById('modalTitle');
    
    if (type === 'buy') {
        modalTitle.textContent = 'Beli Saldo PayPal';
        currentModal = 'buy';
    } else {
        modalTitle.textContent = 'Jual Saldo PayPal';
        currentModal = 'sell';
    }
    
    modal.style.display = 'block';
    calculateTotal();
}

function closeModal() {
    const modal = document.getElementById('orderModal');
    modal.style.display = 'none';
    currentModal = null;
}

// Calculate total
function calculateTotal() {
    const amount = parseFloat(document.getElementById('amount').value) || 0;
    const buyRate = 15000 + 2000; // Rate beli (lebih mahal 2000)
    const sellRate = 15000 - 2000; // Rate jual (lebih murah 2000)
    
    const rate = currentModal === 'buy' ? buyRate : sellRate;
    const total = amount * rate;
    
    const resultDiv = document.getElementById('calculationResult');
    if (amount > 0) {
        resultDiv.innerHTML = `
            <div class="calculation-summary">
                <p><strong>Nominal:</strong> $${amount}</p>
                <p><strong>Rate:</strong> Rp ${rate.toLocaleString('id-ID')}</p>
                <p><strong>Total:</strong> Rp ${total.toLocaleString('id-ID')}</p>
            </div>
        `;
    } else {
        resultDiv.innerHTML = '';
    }
}

// WhatsApp function
function openWhatsApp() {
    const message = encodeURIComponent("Halo cvpaypalki, saya ingin bertanya tentang layanan convert PayPal");
    const phoneNumber = "8107091073142";
    const whatsappUrl = `https://wa.me/${phoneNumber}?text=${message}`;
    window.open(whatsappUrl, '_blank');
}

// Form submission
function handleOrderSubmit(event) {
    event.preventDefault();
    
    const amount = document.getElementById('amount').value;
    const contact = document.getElementById('contact').value;
    
    if (!amount || !contact) {
        alert('Mohon lengkapi semua field');
        return;
    }

    const buyRate = 15000 + 2000;
    const sellRate = 15000 - 2000;
    const rate = currentModal === 'buy' ? buyRate : sellRate;
    const total = amount * rate;
    
    // Create WhatsApp message
    const typeText = currentModal === 'buy' ? 'Pembelian Saldo PayPal' : 'Penjualan Saldo PayPal';
    
    let message = `🧾 *Form ${typeText}*\n\n`;
    message += `Nama: [Isi Nama Anda]\n`;
    message += `Nominal: $${amount}\n`;
    
    if (currentModal === 'buy') {
        message += `Email PayPal: [emailanda@gmail.com]\n`;
        message += `Metode Bayar: [BCA/BNI/DANA/GOPAY/QRIS]\n`;
        message += `Bukti Transfer: (Akan menyusul)\n\n`;
        message += `Catatan Tambahan: -\n\n`;
        message += `Saya sudah transfer dan siap menerima saldo PayPal sesuai ketentuan.`;
    } else {
        message += `Email Pengirim PayPal: [emailpengirim@gmail.com]\n`;
        message += `Metode Terima Uang: [BCA/BNI/DANA/GOPAY/QRIS]\n`;
        message += `Nomor Rekening / e-wallet: [${contact}]\n`;
        message += `Catatan: [saldo dari bisnis, bukan hasil refund]\n\n`;
        message += `Saya setuju dengan rate yang berlaku dan siap kirim saldo PayPal sesuai arahan admin.`;
    }
    
    message += `\n\n⚠️ Mohon pastikan data benar sebelum dikirim.\n`;
    message += `⏳ Proses estimasi 5–30 menit setelah konfirmasi & verifikasi.\n`;
    message += `✅ Transaksi aman & transparan, tidak menerima saldo hasil refund/scam.`;

    // Open WhatsApp
    const encodedMessage = encodeURIComponent(message);
    const phoneNumber = "8107091073142";
    const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodedMessage}`;

    // Send to backend
    fetch('/api/order', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            type: currentModal,
            amount: parseFloat(amount),
            contact: contact
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            window.open(whatsappUrl, '_blank');
            closeModal();
            document.getElementById('orderForm').reset();
            alert('Pesanan berhasil dibuat! Anda akan diarahkan ke WhatsApp.');
        } else {
            alert('Terjadi kesalahan, silakan coba lagi.');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Terjadi kesalahan, silakan coba lagi.');
    });
}

// DOM Content Loaded
document.addEventListener('DOMContentLoaded', function() {
    // Modal event listeners
    const modal = document.getElementById('orderModal');
    const closeBtn = document.querySelector('.close');
    const orderForm = document.getElementById('orderForm');
    const amountInput = document.getElementById('amount');

    // Close modal events
    if (closeBtn) {
        closeBtn.onclick = closeModal;
    }

    window.onclick = function(event) {
        if (event.target === modal) {
            closeModal();
        }
    };

    // Form submission
    if (orderForm) {
        orderForm.addEventListener('submit', handleOrderSubmit);
    }

    // Amount input change
    if (amountInput) {
        amountInput.addEventListener('input', calculateTotal);
    }

    // Smooth scrolling for navigation links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
});
